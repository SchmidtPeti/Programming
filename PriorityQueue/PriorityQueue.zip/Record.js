class Record{
    constructor(item,priority){
        this.item = item;
        this.priority = priority;
    }
}
export default Record;
import InsertionSort from './InsertionSort.js';

let array = [ 28, 79, 74, 73, 56,7,41,39 ];
InsertionSort(array);
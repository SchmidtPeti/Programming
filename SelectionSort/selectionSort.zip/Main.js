import {MinSelectionSort,MaxSelectionSort} from "./SelectionSort.js";

let arr = [5,70,98,19,23,87,15,5];

MaxSelectionSort(arr);
console.log(arr);
import BubbleSort from './BubbleSort.js';

let arr = [64, 34, 25, 12, 80, 11, 90];

BubbleSort(arr);
console.log("After sorting: ",arr);


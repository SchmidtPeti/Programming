import Pig from "./Pig.js";

let PigData = new Pig();
PigData.haveDinnerWithMe();
class NodeData{
    constructor(element){
        this.element = element;
        this.next = null;
    }
}
export default NodeData;

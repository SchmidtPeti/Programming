class Record{
    constructor(element,key){
        this.element = element;
        this.key = key;
    }
}
export default Record;
import ImprovedBubbleSort from './ImprovedBubbleSort.js';

let arr = [98,15,74,48,5,89,57,18];

ImprovedBubbleSort(arr);

console.log("sorted array: ",arr);
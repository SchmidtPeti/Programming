import mergeSort from "./MergeSort.js";

let array = [52, 22, 69,66, 59, 98, 11, 39, 4];
mergeSort(array);
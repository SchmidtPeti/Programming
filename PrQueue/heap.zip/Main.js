import PrQueue from './PrQueue.js';

let list = new PrQueue();

/*list.items = [68, 23, 51, 42, 19, 35, 97, 53, 60,14];
list.n = list.items.length;
list.heapSort();*/


/*
list.add(20);
list.add(10);
list.add(8);
list.add(7);
list.add(18);
console.log(list.items);

list.remMax();
console.log(list.items);*/


list.items = [5, 2, 7, 4, 9, 8, 3, 10];
list.n = 8;
list.heapSort();






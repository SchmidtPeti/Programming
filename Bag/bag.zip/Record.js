class Record{
    constructor(data,count){
        this.key = data;
        this.count = count;
    }
}
export default Record;